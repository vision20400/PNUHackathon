package test;

public abstract class Layout {

    public abstract void execute();

}