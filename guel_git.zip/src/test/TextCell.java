package test;

public class TextCell extends Cell {
	
	public TextCell(String id) {
		super(id);
	}

}
